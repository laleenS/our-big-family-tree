# Restore the uncommitted learning update

Extract `cyber-learning-update.zip` first. Install Git and Python 3.11+ on Windows.
Open PowerShell in the extracted `cyber-learning-review` folder and choose a
**new, nonexistent** destination, for example:

```powershell
py restore.py C:\Labs\cyber-learning
```

The script clones each included base bundle into the new destination, selects the
review branch, removes only old tracked files missing from the current snapshot,
and overlays the current source/docs. It never touches an existing destination.
No commits, pushes or GitHub repositories are created; changes stay unstaged.
It removes the temporary bundle origin, so no remote is configured in the restored labs.

Read HANDOFF.md and each project's LEARN_THIS.md. Run tests from each restored
project folder with `py -m unittest discover -s tests -v`, then review the source
and use the handoff's Git commands if you are ready to commit. Replace its cloud
paths with your new Windows project paths.

If you only want to read/run the files, they are directly available under
`projects\soc-investigation-lab`, `projects\iam-access-review` and
`projects\security-baseline-checker`. Those snapshot folders omit `.git`; use the
restore script to retain history. Plain tracked-file patches under `backups` are
supplementary and omit newly created files. The `projects` snapshots are complete.
