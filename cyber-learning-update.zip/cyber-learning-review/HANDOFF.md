# Cybersecurity learning update

Prepared October 31, 2026. **No new commits, pushes, merges or GitHub repositories
were created in this round.** All edits are unstaged for your review. Previous
round commits remain intact; see the base hashes below. No work was hidden in an
automatic temporary commit.

## What is complete now

| Project / location | Branch | Changes / result |
| --- | --- | --- |
| `/workspace/soc-investigation-lab` | `portfolio/windows-learning` | Renamed existing SOC checkout without losing its Git history. Simpler list/dictionary Python; 18 synthetic events, nine leads, five worked scenarios, triage checklist, rule definitions, Windows/Sysmon/Splunk guide, XML config, planned SPL searches and LEARN_THIS.md |
| `/workspace/iam-access-review` | `portfolio/assa-learning` | Fictional ASSA; separate synthetic HR, directory, role and exception CSVs; 16 directory identities, 11 issues and one documented exception; learning guide, methodology and optional future Entra path |
| `/workspace/security-baseline-checker` | `portfolio/learning-notes` | Added Windows commands and LEARN_THIS.md explaining the existing sample-only checker, Unix permissions versus Windows ACLs, and interview concepts; detection code unchanged |

All three use Python's standard library. No packages, Windows administrator rights,
or credentials are required for the current Python samples. We did not run Windows,
install Sysmon/Splunk, query a real directory, scan the host or generate live screenshots.
All live Splunk/Sysmon tasks remain for you personally; the docs clearly distinguish
the prepared steps from executed sample analysis. The original SOC path no longer
exists; use `soc-investigation-lab` going forward. Web projects were not changed.

## Tests and verification

- SOC: 5 tests passed. Checks evidence IDs, expected rules, exact window boundary,
  expiry/reset, host/account/source separation, benign controls, BOM/timezone parsing
  and malformed/duplicate rows.
- IAM: 5 tests passed. Checks every required scenario, valid emergency access,
  documented versus expired exceptions, boundary dates, privilege controls that a
  generic exception cannot waive, disabled/unmapped cases and invalid exports.
- Baseline: existing 4 tests passed. Insecure sample still produces eight findings;
  safer sample produces no matching rules, not a security guarantee.
- All three CLI reports exactly reproduce the included output, and invalid inputs
  produce nonzero errors. Local Markdown links resolve. Git whitespace checks pass.
- The Sysmon XML is well-formed. Both synthetic encoded commands decode to harmless
  `Write-Output 'LAB'` text. This is **not** validation of Sysmon schema acceptance or
  Splunk searches: those require your Windows/Splunk installation.
- A targeted search found no common token/private-key patterns in the project files.
  All identity data was invented; this check is not a comprehensive secret audit.
- External documentation is linked, but the restricted cloud environment did not
  fetch current Microsoft/Splunk pages. Check current support, licensing and UI
  before installation. No copied public GitHub code or external rule pack was used.

## Review these files first

1. `soc-investigation-lab/LEARN_THIS.md`, then `data/events.csv`, `src/investigate.py`
   and `output/findings.md`. Compare with `investigations/scenarios.md`.
2. `iam-access-review/LEARN_THIS.md`, `data/README.md`, A003/A007/A008/A012 in the
   CSVs, `src/review.py`, then `output/findings.md` and `methodology.md`.
3. `security-baseline-checker/LEARN_THIS.md` for bit masks and the limits of a supplied
   JSON snapshot. This is not a Windows configuration scanner.
4. For later live work, `soc-investigation-lab/docs/windows-splunk-lab.md` and
   `detections/splunk-searches.md`. These are planned instructions, not executed results.

Each LEARN_THIS.md has technical behavior, why the security control matters, practice
suggestions, and ten interview questions with learning points. Start by tracing one
account through the data before trying to learn all of Splunk.

## What you need to run yourself

First install Python 3.11+ on Windows and use ordinary PowerShell in each project.
Run the README commands with `py` (`python3` was used in the cloud). Rewrite the SOC
five-failure loop and the IAM HR join/group comparison yourself. Add one small
synthetic scenario and predict the output before running it.

Then, only on a personal/test computer you can administer, follow the live guide:
check resources/licensing → install/verify Microsoft Sysmon → inspect Event Viewer
→ collect Security and Sysmon locally in Splunk → validate searches → investigate a
benign encoded PowerShell test → save your own redacted evidence. Do not present
prepared SPL, XML or synthetic findings as a live SIEM detection you have already run.
No enterprise domain, second PC, expensive infrastructure or live attack is required.

## Exact final commit commands — for you to run after review

These are **not executed** by the assistant. In the cloud Bash terminal:

```bash
cd /workspace/soc-investigation-lab
git status --short
git branch --show-current
git diff -- README.md src/investigate.py tests/test_investigate.py investigations/scenarios.md
git add -A
git diff --cached --check
git diff --cached --stat
git diff --cached
git commit -m "Add Windows SOC learning path"

cd /workspace/iam-access-review
git status --short
git branch --show-current
git diff -- README.md src/review.py tests/test_review.py methodology.md
git add -A
git diff --cached --check
git diff --cached --stat
git diff --cached
git commit -m "Build fictional ASSA access review"

cd /workspace/security-baseline-checker
git status --short
git branch --show-current
git diff -- README.md
git add README.md LEARN_THIS.md
git diff --cached --check
git diff --cached
git commit -m "Add Windows learning guide"
```

Before `git add -A`, confirm only intended lab files appear in status. The staged
review is important: newly created files are not shown by plain `git diff`. The
commands do not push or merge anything. On Windows, replace the `/workspace/...`
paths with the folder where you restored/extracted each project; other Git commands
are the same. If you open a new empty repository instead, initialize a review branch
with `git init -b portfolio/windows-learning` (or the corresponding IAM/baseline
branch) before staging. Do not run `git init` inside an unrelated checkout.

## Preserve uncommitted work

`/workspace/cyber-learning-update.zip` contains complete current source/docs for the
three projects, base Git bundles, tracked-file patches, this handoff and restore
instructions. **Download it before discarding the cloud machine.** The bundles
contain previous commits only; the latest updates are deliberately uncommitted.
The ZIP's source trees include new files that a plain Git diff patch cannot capture.

Base commits from the previous round (automatically created then, not in this round):

- SOC: `d4d415c83a08803dabcb51b1bd2f33e7e6c8b9bf`
- IAM: `930267ba2a1128f4be0f3749991eb6cc1b62a2af`
- Baseline: `3af0f83d5c6eb9bb62c3e673e4ff13ea74d0fabe`

Cloud start instructions were updated to the renamed paths, current CLI commands,
14 tests, and your no-automatic-commit rule. That draft save does not publish a new
snapshot or commit source. The old `/workspace/portfolio-review.zip` is from the
previous round and does not contain these learning updates.
