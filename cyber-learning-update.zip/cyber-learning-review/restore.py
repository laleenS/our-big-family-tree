"""Restore into a NEW folder after extracting cyber-learning-update.zip."""
import argparse
from pathlib import Path
import shutil
import subprocess

BRANCHES = {
    "soc-investigation-lab": "portfolio/windows-learning",
    "iam-access-review": "portfolio/assa-learning",
    "security-baseline-checker": "portfolio/learning-notes",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path, help="A new folder that does not yet exist")
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    if args.destination.exists():
        parser.error("Destination already exists. Choose a new folder to protect existing work.")
    args.destination.mkdir(parents=True)
    for name, branch in BRANCHES.items():
        checkout = args.destination / name
        source = package / "projects" / name
        subprocess.run(["git", "clone", "--branch", branch,
                        str(package / "backups" / (name + ".bundle")), str(checkout)], check=True)
        subprocess.run(["git", "-C", str(checkout), "remote", "remove", "origin"], check=True)
        tracked = subprocess.check_output(["git", "-C", str(checkout), "ls-files"], text=True)
        # These are fresh bundle clones, not existing user checkouts.
        for relative in tracked.splitlines():
            if not (source / relative).exists():
                (checkout / relative).unlink()
        shutil.copytree(source, checkout, dirs_exist_ok=True)
        subprocess.run(["git", "-C", str(checkout), "status", "--short"], check=True)
    print("Restored three review branches with uncommitted changes. No commits or pushes were made.")


if __name__ == "__main__":
    main()
