# Optional future Microsoft Entra ID exercise

**Not performed.** ASSA is fictional and this project uses local CSVs only.
Do not create or use a real government/employer directory for a portfolio exercise.
If you later have your own authorized test tenant and the required licensing:

1. Check current Microsoft documentation, tenant permissions and feature licensing.
   Some access-review and governance features are paid; do not assume a free tenant
   includes them. CSV exercises remain useful without any tenant.
2. Use only disposable test users/groups with invented names. Create a few roles,
   one expired contractor scenario and a small explicit exception register. Never
   export real staff data into this public project.
3. Inspect user status and group memberships, and distinguish direct from inherited
   access. Separately inspect MFA registration and enforcement: neither is proven
   by a single Boolean or by creating an authentication method.
4. Export a small test-only dataset, normalize it to this lab's documented columns,
   and explain differences rather than claiming the script directly integrates.
5. Perform a manual manager/application-owner review. If licensed, compare it with
   an Entra access review. Record what actually ran, permission/license limits,
   decisions, redacted evidence and cleanup. Disable only your own test identities.

Reference: [Microsoft Entra identity governance documentation](https://learn.microsoft.com/en-us/entra/id-governance/).
No screenshots or tenant results have been created for this optional stage.
