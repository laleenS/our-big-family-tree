# Synthetic ASSA records

Aegis State Services Agency (ASSA) is fictional. All names beginning with Demo,
lab.* usernames, identifiers, managers and approvals below were invented for this
exercise. No employee, contractor or government directory export is represented.

| File | Represents | Important fields |
| --- | --- | --- |
| hr_roster.csv | Authoritative employment/lifecycle snapshot | employee_id, worker_type, status, department, role, manager_id, contract_end, previous_department |
| directory_users.csv | Observed identity/access snapshot | matching employee_id, username, enabled, last_login, mfa_enabled, groups |
| role_matrix.csv | Fictional approved RBAC baseline | role, department, allowed_groups |
| exceptions.csv | Synthetic approval register | exception_id, employee_id, group, approved_by, reason, expires_on |

Join records by `employee_id`, not names. Each CSV ID must be unique. Only one
directory account per identity is modeled. Groups are semicolon-separated. Dates
are ISO YYYY-MM-DD; `yes` and `no` are literal values. Blank contractor end date
or login date means unknown and needs review. Contractors remain valid through
the end date; an exception is valid through its expiry date, inclusive.

M01–M03 are fictional managers included in HR and directory data. A007's emergency
access belongs to the normal Emergency Coordinator role. A008 has extra emergency
coordination access supported by synthetic EX-001 through November 15, 2026. A012's
records access has only an expired EX-002; it is not treated as a valid exception.

The extra-group exception check requires a matching identity/group, a nonempty
reason, an approver ID present in HR, and an unexpired date. The register is assumed
to be a reviewed input: this does not authenticate signatures or establish that an
approver had authority. Confirm that separately during certification. General group
exceptions do **not** suppress offboarding, contract, privileged/MFA or invoice
segregation-of-duties checks. Approvals can be incomplete or wrong in real exports.

No passwords, email addresses, real phone numbers or secrets are included. Keep real
HR and directory exports out of a public portfolio.
