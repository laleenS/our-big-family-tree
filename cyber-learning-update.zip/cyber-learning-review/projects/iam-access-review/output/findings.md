# ASSA synthetic access review

Aegis State Services Agency (ASSA) — fictional lab organization
Review date: 2026-10-31
Reviewed 16 directory identities: 11 issues needing review; 1 documented exception(s).
All people, managers, approvals and records are invented. No real directory was queried or changed.

## HIGH — lab.rowan (A001) — leaver-still-enabled
Disposition: needs review
HR status is terminated, but directory enabled=yes.
Why it matters: Former or inactive staff may still be able to sign in.
Recommendation: Confirm HR status, disable sign-in, revoke sessions and review retained groups through offboarding.

## HIGH — lab.quinn (A002) — contract-review
Disposition: needs review
Enabled contractor; contract_end=2026-10-15.
Why it matters: Time-limited access can outlast its approved business need.
Recommendation: Ask the sponsor to verify extension or remove access under the contractor offboarding process.

## MEDIUM — lab.ellis (A003) — excess-group
Disposition: needs review
Group invoice-create is outside role HR Specialist; previous department: Finance. No valid documented exception.
Why it matters: Unneeded permissions increase the possible impact of account misuse.
Recommendation: Check for privilege creep after a transfer or an expired exception; remove unless the owner justifies access.

## MEDIUM — lab.avery (A004) — excess-group
Disposition: needs review
Group it-admin is outside role Operations Clerk; previous department: none recorded. No valid documented exception.
Why it matters: Unneeded permissions increase the possible impact of account misuse.
Recommendation: Check for privilege creep after a transfer or an expired exception; remove unless the owner justifies access.

## HIGH — lab.avery (A004) — unexpected-privilege
Disposition: needs review
Privileged group it-admin is not part of role Operations Clerk.
Why it matters: Administrative access has greater impact and needs specific authorization.
Recommendation: Review privileged role assignment separately; a general group exception does not authorize admin access.

## HIGH — lab.morgan.admin (A005) — privileged-without-mfa
Disposition: needs review
Privileged enabled identity has mfa_enabled=no.
Why it matters: A password-only privileged sign-in has fewer barriers against credential misuse.
Recommendation: Verify registration and enforcement, then require MFA and review recent privileged sign-ins.

## MEDIUM — lab.casey (A006) — stale-account
Disposition: needs review
Last login: 2026-06-01; review date 2026-10-31 (90-day lab threshold).
Why it matters: Unused accounts can retain access no longer needed by their owners.
Recommendation: Check leave, seasonal work and business need with the manager before disabling.

## INFO — lab.cameron (A008) — documented-exception
Disposition: documented exception — retain for this review
Extra group emergency-access; EX-001, approved by M03 through 2026-11-15. Reason: Temporary records liaison for a fictional emergency exercise; read-only coordination access
Why it matters: Temporary business needs can justify unusual access when reviewed and time-limited.
Recommendation: Confirm the approval evidence and expiry with the owner; no removal recommended while the exception remains valid.

## MEDIUM — lab.jordan (A009) — excess-group
Disposition: needs review
Group invoice-approve is outside role Finance Analyst; previous department: none recorded. No valid documented exception.
Why it matters: Unneeded permissions increase the possible impact of account misuse.
Recommendation: Check for privilege creep after a transfer or an expired exception; remove unless the owner justifies access.

## HIGH — lab.jordan (A009) — segregation-of-duties
Disposition: needs review
Identity can both create and approve invoices.
Why it matters: Creating and approving the same transaction removes independent oversight.
Recommendation: Separate request and approval duties, or obtain a specific compensating-control decision; a group exception alone is not enough.

## MEDIUM — lab.drew (A012) — excess-group
Disposition: needs review
Group records-read is outside role Finance Analyst; previous department: none recorded. No valid documented exception.
Why it matters: Unneeded permissions increase the possible impact of account misuse.
Recommendation: Check for privilege creep after a transfer or an expired exception; remove unless the owner justifies access.

## HIGH — lab.unknown (A099) — no-hr-record
Disposition: needs review
Directory identity has no matching HR record.
Why it matters: An identity without a reconciled owner may retain unapproved access.
Recommendation: Identify the owner and purpose; do not assume an unknown identity is authorized.
