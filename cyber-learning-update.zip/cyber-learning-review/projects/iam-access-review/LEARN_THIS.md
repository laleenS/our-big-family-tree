# Learn this before presenting the ASSA lab

Aegis State Services Agency (ASSA) is fictional. The data, approvals and recommendations
are exercises. You have not reviewed a real government directory or Entra tenant.
The prepared Python was executed in the cloud; run and study it yourself before
claiming personal hands-on use.

## Start with one person, not the whole report

Open A003 in `data/hr_roster.csv`, then the same ID in `directory_users.csv`.
Compare the Human Resources role in `role_matrix.csv`: why is invoice-create left
over? Next compare A007 and A008: one has role-approved emergency access, the other
has a temporary documented exception. Then compare A012's expired exception.
Run the Windows README commands and find those same identities in `output/findings.md`.

## The code in plain terms

- `load_data()` reads four CSVs and checks basic headers, IDs, dates and yes/no flags.
  `csv.DictReader` makes each row a dictionary; exports can have a Windows UTF-8 BOM.
- `review()` builds ordinary dictionaries keyed by employee ID and role name. It
  loops through directory accounts, finds the corresponding HR record, then runs
  lifecycle, stale, group, privilege, MFA and duty-conflict checks.
- `add_finding()` appends one dictionary. `report()` formats the list as Markdown;
  the output records informational exceptions separately from issues needing review.
- `main()` handles command-line filenames/date with the standard `argparse` library.
  No AD query, API call or remediation command is hidden in these functions.

Two useful ideas beyond loops and CSV:

1. **Joining datasets by a stable key.** Build `hr_by_id[employee_id] = person`, then
   look up each directory account. Names can change or collide; IDs link records.
   `.get()` returns `None` when no match exists, allowing an orphan-account finding.
2. **Date arithmetic.** Parse YYYY-MM-DD with `date.fromisoformat`; subtract dates
   to count elapsed days. More than 90 days is stale here, exactly 90 is not. A
   contractor/exception remains valid on its end date, then expires the next day.

The tool uses explicit loops and list membership checks, not advanced data-analysis
packages. `None` means no record/value was found, not the string "None". Tests use
unittest classes as a small standard-library harness; you do not need to introduce
classes into the reviewer.

## Security concepts: technical check and why it matters

| Concept | What the project checks/records | Explain why it matters |
| --- | --- | --- |
| Least privilege | Assigned groups versus approved role groups | Unneeded access increases potential impact when an account is misused |
| RBAC | Role matrix grants normal groups by job role/department | A maintainable baseline makes access decisions consistent, but it still needs owner review |
| Joiner | HR identity and role match the directory account | New access should have a sponsor and business need, not just an account name |
| Mover / privilege creep | A003's previous department and leftover invoice group | Access can accumulate across transfers if old permissions are never removed |
| Leaver | HR inactive/terminated while enabled=yes | Former staff should not retain usable accounts; review sessions and access during offboarding |
| Contractor | Contract date versus fixed review date | Temporary access needs a sponsor and end date; active HR status alone is insufficient |
| Privileged access | it-admin/security-admin versus role baseline | Powerful access has greater impact and needs explicit authorization, not automatic removal of every admin |
| MFA | Enabled privileged account with mfa_enabled=no | MFA reduces reliance on a password, but registration flags are not proof that policy enforces it |
| Stale accounts | Last login over 90 days or unknown | Unused access may no longer be justified; seasonal work/leave are important context |
| Segregation of duties | Both invoice-create and invoice-approve | One person should not ordinarily request and approve the same transaction without independent review |
| Exceptions | Matching group/identity, documented reason/approver and expiry | Legitimate temporary access should be traceable, limited and revisited; unusual does not mean wrong |
| Access certification | Human retain/remove/modify decision described in methodology | A responsible owner confirms business need; code highlights discrepancies but cannot certify access |

Emergency Management is not inherently privileged IT administration. A007's
emergency-access group is normal for that role. A008's extra group initially looks
wrong, but EX-001 explains temporary liaison duties. It is reported as information,
not an unresolved vulnerability. An expired exception or missing approval is different.
Do not treat a CSV approval entry as independent proof of a real person's authority.

## Ten interview questions — points to be able to explain

1. **Why separate HR and directory data?** HR describes employment/lifecycle;
   directory data describes observed enabled accounts and groups. They can disagree.
2. **Why use employee IDs instead of names?** Stable joins, uniqueness checks and
   explicit handling of unmatched records; one account per identity is a lab limit.
3. **How do you identify privilege creep?** A transfer's current role versus old
   retained access, with owner confirmation before removal.
4. **Why isn't every admin account a problem?** Some roles need it; authorization,
   separation of identities where appropriate and MFA are separate considerations.
5. **What does the MFA field prove?** Only the exported flag. Registration and actual
   sign-in enforcement must be checked separately in a real environment.
6. **What makes a contractor different?** Sponsor, approved task and time-limited
   access; explain expiry on the review date versus the following day.
7. **Why can stale-account findings be false positives?** Leave, seasonal roles and
   incomplete login data; assess need rather than indiscriminately deleting.
8. **Why retain A008's unusual access?** Match identity/group/approval/reason/expiry,
   confirm owner evidence, and revisit the end date. Explain why A012 differs.
9. **How is segregation of duties different from RBAC?** Two individually reasonable
   permissions can conflict when held together; a generic group exception cannot waive it.
10. **What is access certification and what would you do after it?** Owner attestation,
    documented decisions/exceptions, authorized remediation, then a new export to verify.

Practice: rewrite the HR join and group comparison. Add a fictional department
transfer and an exception expiring exactly on the review date. Predict the report,
then run tests. Explain the recommendation in your own words rather than memorizing
an answer. Do not claim real government, AD or Entra work from synthetic evidence.
