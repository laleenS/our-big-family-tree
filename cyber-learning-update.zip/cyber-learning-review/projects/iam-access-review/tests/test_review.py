import copy
import shutil
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from review import load_data, review

ROOT = Path(__file__).resolve().parents[1]
AS_OF = date(2026, 10, 31)


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.hr, self.directory, self.roles, self.exceptions = load_data(ROOT / "data", AS_OF)

    def findings(self):
        return review(self.hr, self.directory, self.roles, self.exceptions, AS_OF)

    def test_sample_has_contextual_controls_and_expected_issues(self):
        findings = self.findings()
        self.assertEqual(len(findings), 12)
        self.assertEqual(sum(item["severity"] != "info" for item in findings), 11)
        by_user = {}
        for item in findings:
            by_user.setdefault(item["employee_id"], []).append(item["rule"])
        self.assertEqual(by_user["A008"], ["documented-exception"])
        for allowed in ["A007", "A010", "A011", "M01", "M02", "M03"]:
            self.assertNotIn(allowed, by_user)
        self.assertIn("leaver-still-enabled", by_user["A001"])
        self.assertIn("contract-review", by_user["A002"])
        self.assertIn("unexpected-privilege", by_user["A004"])
        self.assertIn("privileged-without-mfa", by_user["A005"])
        self.assertIn("segregation-of-duties", by_user["A009"])
        self.assertIn("excess-group", by_user["A012"])
        self.assertIn("no-hr-record", by_user["A099"])

    def test_stale_and_contractor_date_boundaries(self):
        person = self.hr[1]
        person["contract_end"] = AS_OF.isoformat()
        account = self.directory[1]
        account["last_login"] = (AS_OF - timedelta(days=90)).isoformat()
        self.assertFalse(any(item["employee_id"] == "A002" for item in self.findings()))
        account["last_login"] = (AS_OF - timedelta(days=91)).isoformat()
        person["contract_end"] = (AS_OF - timedelta(days=1)).isoformat()
        rules = [item["rule"] for item in self.findings() if item["employee_id"] == "A002"]
        self.assertEqual(rules, ["contract-review", "stale-account"])

    def test_exception_expiry_approver_and_independent_controls(self):
        self.exceptions[0]["expires_on"] = AS_OF.isoformat()
        self.assertTrue(any(item["rule"] == "documented-exception" for item in self.findings()))
        self.exceptions[0]["expires_on"] = (AS_OF - timedelta(days=1)).isoformat()
        self.assertFalse(any(item["rule"] == "documented-exception" for item in self.findings()))
        self.exceptions[0]["expires_on"] = "2026-12-31"
        self.exceptions[0]["approved_by"] = "not-in-hr"
        self.assertFalse(any(item["rule"] == "documented-exception" for item in self.findings()))
        exception = copy.deepcopy(self.exceptions[0])
        exception.update(employee_id="A004", group="it-admin", approved_by="M01")
        self.exceptions.append(exception)
        self.assertTrue(any(item["employee_id"] == "A004" and item["rule"] == "unexpected-privilege" for item in self.findings()))

    def test_unknown_role_and_disabled_leaver(self):
        self.hr[0]["role"] = "Unmapped test role"
        self.assertTrue(any(item["rule"] == "unmapped-role" for item in self.findings()))
        self.directory[0]["enabled"] = "no"
        self.assertFalse(any(item["employee_id"] == "A001" for item in self.findings()))

    def test_reader_rejects_duplicates_and_future_login_dates(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            for path in (ROOT / "data").glob("*.csv"):
                shutil.copy(path, folder / path.name)
            path = folder / "directory_users.csv"
            text = path.read_text()
            path.write_text(text + text.splitlines()[1] + "\n")
            with self.assertRaisesRegex(ValueError, "unique"):
                load_data(folder, AS_OF)
            path.write_text(text.replace("2026-10-28", "2026-11-01"))
            with self.assertRaisesRegex(ValueError, "after"):
                load_data(folder, AS_OF)


if __name__ == "__main__":
    unittest.main()
