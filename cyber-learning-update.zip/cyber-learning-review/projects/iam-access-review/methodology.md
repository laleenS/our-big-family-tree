# Fictional ASSA access-review method

Aegis State Services Agency (ASSA) and all records in this exercise are fictional.
Review date: October 31, 2026. Python output was generated in the cloud workspace;
no live agency or tenant was reviewed.

## Method

1. **Gather records:** HR is the lab's authority for employment status, department,
   role, sponsor/manager and contractor end date. Directory data describes enabled
   identities, assigned groups, last login and an exported MFA flag. Confirm export
   date/completeness before comparing. The MFA flag alone does not prove enforcement.
2. **Compare identities:** join by employee_id. Flag an account with no HR match;
   verify whether it is an unrecorded contractor/service identity rather than
   automatically deleting it. Enabled leavers and expired/undated contractors
   need sponsor/HR confirmation and timely offboarding.
3. **Check roles and lifecycle:** compare direct groups with the role matrix.
   Transfers can retain old groups (privilege creep). Flag stale/unknown logins
   with a 90-day lab threshold; ask about leave or seasonal duty before removing.
4. **Review high-impact access:** examine it-admin/security-admin, MFA gaps, and
   invoice-create combined with invoice-approve. Appropriate privileged access
   still needs MFA. An extra-group exception cannot waive these separate checks.
5. **Validate exceptions:** check the synthetic register's identity, group, approver,
   reason and expiry. Confirm actual approval authority/evidence with the manager
   or application owner before accepting it. Emergency work is not a blanket waiver.
6. **Certify and recommend:** the owner records retain/remove/modify/exception,
   supporting evidence, responsible person and due date. The script recommends;
   it does not perform access certification. After authorized remediation, re-export
   and compare again. No real remediation was performed here.

## Sample review decisions to practice

| Identity | Evidence / result | Analyst recommendation |
| --- | --- | --- |
| A001 lab.rowan | HR terminated; directory still enabled | Verify HR termination and complete offboarding, including sessions and group access |
| A002 lab.quinn | Active contractor; contract ended October 15 | Confirm sponsor extension or disable through normal contractor process |
| A003 lab.ellis | Moved Finance → Human Resources; retained invoice-create | Check transfer request; remove old finance access if no current business need |
| A004 lab.avery | Operations role has it-admin | Review accidental assignment; remove privileged group unless separately authorized; two related flags describe one access problem |
| A005 lab.morgan.admin | Security role permits admin group, but MFA=no | Do not remove valid role just because it is powerful; fix verified MFA registration/enforcement gap |
| A006 lab.casey | Last login June 1, 152 days before review | Ask manager about continued need and leave; stale is not automatic maliciousness |
| A007 lab.riley | Emergency Coordinator legitimately has emergency-access | Retain role-aligned access; unusual scope alone is not a finding |
| A008 lab.cameron | Extra emergency-access supported by EX-001 | Informational documented exception: retain for this review, confirm owner evidence, recheck November 15 expiry |
| A009 lab.jordan | Can create and approve invoices | Separate duties or obtain a specific compensating-control decision; group baseline and SoD are related but distinct |
| A010 lab.taylor / A011 lab.alex | Baseline HR access / contractor with future end date | No rule matches; still subject to owner certification |
| A012 lab.drew | Records access exception expired October 15 | Remove access or obtain a new justified approval; do not silently renew it |
| A099 lab.unknown | Directory identity with no HR record | Identify owner/purpose and reconcile data; no assumption that an orphan is authorized |

The report lists **11 issues and one documented exception**, not 12 confirmed
security incidents. A008 demonstrates contextual judgment; A007 demonstrates an
appropriate role baseline. “No rule matched” is not proof of correct effective access.

## Limits and false positives

Leave, seasonal work, delayed HR exports, temporary projects and valid emergency
coverage can look unusual. Missing login dates are unknown, not proof of no use.
Nested groups, shared/service identities, multiple admin accounts, permission
inheritance and time-bound activation are not modeled. An export may list MFA as
registered without enforcing it. Approval records here are assumed synthetic inputs;
no digital signature or real approval authority is verified.
