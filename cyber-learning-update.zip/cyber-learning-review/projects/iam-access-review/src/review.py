"""Compare synthetic ASSA HR, directory, role and exception CSV exports."""
import argparse
import csv
from datetime import date
from pathlib import Path

AGENCY = "Aegis State Services Agency (ASSA) — fictional lab organization"
PRIVILEGED_GROUPS = ["it-admin", "security-admin"]
REASONS = {
    "no-hr-record": "An identity without a reconciled owner may retain unapproved access.",
    "leaver-still-enabled": "Former or inactive staff may still be able to sign in.",
    "contract-review": "Time-limited access can outlast its approved business need.",
    "stale-account": "Unused accounts can retain access no longer needed by their owners.",
    "unmapped-role": "Without a role baseline, excess access cannot be assessed reliably.",
    "role-department-mismatch": "Incorrect lifecycle data can hide access left behind after a transfer.",
    "documented-exception": "Temporary business needs can justify unusual access when reviewed and time-limited.",
    "excess-group": "Unneeded permissions increase the possible impact of account misuse.",
    "unexpected-privilege": "Administrative access has greater impact and needs specific authorization.",
    "privileged-without-mfa": "A password-only privileged sign-in has fewer barriers against credential misuse.",
    "segregation-of-duties": "Creating and approving the same transaction removes independent oversight.",
}


def read_csv(path, columns, id_column):
    records = []
    seen_ids = []
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        for column in columns:
            if column not in (reader.fieldnames or []):
                raise ValueError(f"{path.name}: missing column {column}")
        for line, row in enumerate(reader, 2):
            for column in columns:
                if row[column] is None:
                    raise ValueError(f"{path.name} line {line}: missing value for {column}")
                row[column] = row[column].strip()
            record_id = row[id_column]
            if not record_id or record_id in seen_ids:
                raise ValueError(f"{path.name} line {line}: {id_column} must be present and unique")
            seen_ids.append(record_id)
            records.append(row)
    return records


def load_data(folder, as_of):
    folder = Path(folder)
    hr = read_csv(folder / "hr_roster.csv", ["employee_id", "name", "worker_type", "department",
                  "role", "status", "manager_id", "contract_end", "previous_department"], "employee_id")
    directory = read_csv(folder / "directory_users.csv", ["employee_id", "username", "enabled",
                         "last_login", "mfa_enabled", "groups"], "employee_id")
    roles = read_csv(folder / "role_matrix.csv", ["role", "department", "allowed_groups"], "role")
    exceptions = read_csv(folder / "exceptions.csv", ["exception_id", "employee_id", "group",
                          "approved_by", "reason", "expires_on"], "exception_id")
    for person in hr:
        if person["status"] not in ["active", "terminated", "inactive"]:
            raise ValueError("HR status must be active, terminated or inactive")
        if person["worker_type"] not in ["employee", "contractor"]:
            raise ValueError("worker_type must be employee or contractor")
        if not person["name"] or not person["department"] or not person["role"]:
            raise ValueError("HR name, department and role are required")
        if person["contract_end"]:
            date.fromisoformat(person["contract_end"])
    for account in directory:
        if not account["username"] or account["enabled"] not in ["yes", "no"] or account["mfa_enabled"] not in ["yes", "no"]:
            raise ValueError("directory needs a username and yes/no values for enabled and mfa_enabled")
        if account["last_login"] and date.fromisoformat(account["last_login"]) > as_of:
            raise ValueError("last_login is after the review date")
    for exception in exceptions:
        date.fromisoformat(exception["expires_on"])
    return hr, directory, roles, exceptions


def add_finding(findings, account, rule, severity, evidence, recommendation, status="needs review"):
    findings.append({"user": account["username"], "employee_id": account["employee_id"],
                     "rule": rule, "severity": severity, "status": status,
                     "evidence": evidence, "why": REASONS[rule], "recommendation": recommendation})


def review(hr, directory, roles, exceptions, as_of):
    findings = []
    hr_by_id = {}
    for person in hr:
        hr_by_id[person["employee_id"]] = person
    role_by_name = {}
    for role in roles:
        role_by_name[role["role"]] = role

    for account in directory:
        enabled = account["enabled"] == "yes"
        person = hr_by_id.get(account["employee_id"])
        if person is None:
            add_finding(findings, account, "no-hr-record", "high", "Directory identity has no matching HR record.",
                        "Identify the owner and purpose; do not assume an unknown identity is authorized.")
            continue
        if not enabled:
            continue
        if person["status"] != "active":
            add_finding(findings, account, "leaver-still-enabled", "high",
                        f"HR status is {person['status']}, but directory enabled=yes.",
                        "Confirm HR status, disable sign-in, revoke sessions and review retained groups through offboarding.")
        if person["worker_type"] == "contractor":
            end = person["contract_end"]
            if not end or date.fromisoformat(end) < as_of:
                add_finding(findings, account, "contract-review", "high",
                            f"Enabled contractor; contract_end={end or 'unknown'}.",
                            "Ask the sponsor to verify extension or remove access under the contractor offboarding process.")
        last_login = account["last_login"]
        if not last_login or (as_of - date.fromisoformat(last_login)).days > 90:
            add_finding(findings, account, "stale-account", "medium",
                        f"Last login: {last_login or 'unknown'}; review date {as_of} (90-day lab threshold).",
                        "Check leave, seasonal work and business need with the manager before disabling.")
        groups = []
        for group in account["groups"].split(";"):
            if group.strip():
                groups.append(group.strip())
        role = role_by_name.get(person["role"])
        allowed = []
        if role is None:
            add_finding(findings, account, "unmapped-role", "medium", f"No role matrix entry for {person['role']}.",
                        "Ask the role owner to establish a baseline; do not treat unmapped access as approved.")
        else:
            allowed = role["allowed_groups"].split(";")
            if role["department"] != person["department"]:
                add_finding(findings, account, "role-department-mismatch", "medium",
                            f"HR department {person['department']}; role belongs to {role['department']}.",
                            "Verify the transfer record and correct the role or department before certifying access.")
            for group in groups:
                if group in allowed:
                    continue
                approved_exception = None
                for exception in exceptions:
                    if exception["employee_id"] == account["employee_id"] and exception["group"] == group:
                        if exception["approved_by"] in hr_by_id and exception["reason"] and date.fromisoformat(exception["expires_on"]) >= as_of:
                            approved_exception = exception
                            break
                if approved_exception is not None:
                    add_finding(findings, account, "documented-exception", "info",
                                f"Extra group {group}; {approved_exception['exception_id']}, approved by {approved_exception['approved_by']} through {approved_exception['expires_on']}. Reason: {approved_exception['reason']}",
                                "Confirm the approval evidence and expiry with the owner; no removal recommended while the exception remains valid.",
                                status="documented exception — retain for this review")
                else:
                    previous = person["previous_department"] or "none recorded"
                    add_finding(findings, account, "excess-group", "medium",
                                f"Group {group} is outside role {person['role']}; previous department: {previous}. No valid documented exception.",
                                "Check for privilege creep after a transfer or an expired exception; remove unless the owner justifies access.")
        privileged = False
        for group in groups:
            if group in PRIVILEGED_GROUPS:
                privileged = True
                if group not in allowed:
                    add_finding(findings, account, "unexpected-privilege", "high", f"Privileged group {group} is not part of role {person['role']}.",
                                "Review privileged role assignment separately; a general group exception does not authorize admin access.")
        if privileged and account["mfa_enabled"] != "yes":
            add_finding(findings, account, "privileged-without-mfa", "high", "Privileged enabled identity has mfa_enabled=no.",
                        "Verify registration and enforcement, then require MFA and review recent privileged sign-ins.")
        if "invoice-create" in groups and "invoice-approve" in groups:
            add_finding(findings, account, "segregation-of-duties", "high", "Identity can both create and approve invoices.",
                        "Separate request and approval duties, or obtain a specific compensating-control decision; a group exception alone is not enough.")
    return findings


def report(directory, findings, as_of):
    issues = 0
    exceptions = 0
    for item in findings:
        if item["rule"] == "documented-exception":
            exceptions += 1
        else:
            issues += 1
    lines = ["# ASSA synthetic access review", "", AGENCY, f"Review date: {as_of}",
             f"Reviewed {len(directory)} directory identities: {issues} issues needing review; {exceptions} documented exception(s).",
             "All people, managers, approvals and records are invented. No real directory was queried or changed.", ""]
    for item in findings:
        lines.append(f"## {item['severity'].upper()} — {item['user']} ({item['employee_id']}) — {item['rule']}")
        lines.append("Disposition: " + item["status"])
        lines.append(item["evidence"])
        lines.append("Why it matters: " + item["why"])
        lines.append("Recommendation: " + item["recommendation"])
        lines.append("")
    if not findings:
        lines.append("No rules matched. This narrow review cannot certify all access.")
    return "\n".join(lines).rstrip() + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_folder", type=Path)
    parser.add_argument("--as-of", type=date.fromisoformat, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        hr, directory, roles, exceptions = load_data(args.data_folder, args.as_of)
        text = report(directory, review(hr, directory, roles, exceptions, args.as_of), args.as_of)
        if args.output:
            args.output.write_text(text, encoding="utf-8")
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(text, end="")


if __name__ == "__main__":
    main()
