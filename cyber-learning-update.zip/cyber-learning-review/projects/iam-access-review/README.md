# IAM access review: fictional ASSA

**Aegis State Services Agency (ASSA) is a completely fictional government agency
created for this lab.** Every person, manager, account and approval is synthetic.
This tool does not connect to a government system, Active Directory or Microsoft
Entra ID, and it never disables accounts or changes permissions.

The Python script compares HR employment records, directory accounts, a role matrix
and documented exceptions. It flags leavers, expired contractors, stale access,
privilege creep, privileged MFA gaps and conflicting invoice duties. It also shows
why some unusual emergency access is legitimate.

## Run on Windows

Use Python 3.11+ and PowerShell in this folder. No packages or administrator rights
are needed:

```powershell
py src/review.py data --as-of 2026-10-31 --output output/findings.md
py -m unittest discover -s tests -v
```

If needed, substitute `python` after checking its version. On Linux use `python3`.
The fixed date makes the supplied report reproducible. Analysis exits zero even
with findings; malformed input exits nonzero. Do not use today's date to reproduce
the October sample, because contracts, stale dates and exceptions will change.

Start with [LEARN_THIS.md](LEARN_THIS.md), then compare
[output/findings.md](output/findings.md) with [methodology.md](methodology.md).
The sample contains 16 directory identities, 11 issues needing review and one
informational documented exception. Read `data/README.md` before editing exports.

Limits: one account per identity, direct groups only, simplified roles/approval
records, no effective-permission calculation or real MFA enforcement evidence.
Disabled known accounts are outside active-access checks; missing HR matches still
need investigation. A clean result is not access certification. Certification is
an accountable owner decision, not a script return code. An optional future Entra
exercise is described in [docs/entra-next-step.md](docs/entra-next-step.md).
