"""Check a supplied JSON configuration snapshot. Never reads or changes host settings."""
import argparse
import json
from ipaddress import ip_address
from pathlib import Path


def check(config):
    if not isinstance(config, dict):
        raise ValueError("configuration must be a JSON object")
    findings = []

    def flag(rule, severity, evidence, recommendation):
        findings.append({"rule": rule, "severity": severity, "evidence": evidence,
                         "recommendation": recommendation})

    for section in ("ssh", "password_policy", "firewall_enabled", "services", "files"):
        if section not in config:
            flag("missing-setting", "medium", f"Missing section: {section}.",
                 "Collect this setting before considering the baseline review complete.")

    def setting(section, key, expected_type):
        if section not in config:
            return None
        values = config[section]
        if not isinstance(values, dict):
            raise ValueError(f"{section} must be an object")
        if key not in values:
            flag("missing-setting", "medium", f"Missing {section}.{key}.",
                 "Collect the effective setting; a missing value is not a secure default.")
            return None
        value = values[key]
        if type(value) is not expected_type:
            raise ValueError(f"{section}.{key} must be {expected_type.__name__}")
        return value

    root_login = setting("ssh", "permit_root_login", bool)
    password_auth = setting("ssh", "password_authentication", bool)
    if root_login:
        flag("root-ssh", "high", "Direct root SSH login is enabled.",
             "Use named accounts with reviewed sudo access; disable direct root login after testing recovery access.")
    if password_auth:
        flag("ssh-password", "medium", "SSH accepts password authentication.",
             "Prefer managed SSH keys and MFA where available; verify working access before disabling passwords.")
    minimum = setting("password_policy", "min_length", int)
    if minimum is not None:
        if minimum < 1:
            raise ValueError("password_policy.min_length must be positive")
        if minimum < 15:
            flag("short-password", "medium", f"Minimum password length is {minimum}; lab target is 15.",
                 "Use long passwords/passphrases, a breached-password blocklist, and MFA. Length alone is insufficient.")
    if "firewall_enabled" in config:
        if type(config["firewall_enabled"]) is not bool:
            raise ValueError("firewall_enabled must be bool")
        if not config["firewall_enabled"]:
            flag("firewall-disabled", "high", "Snapshot reports host firewall disabled.",
                 "Review required flows, then enable a default-deny inbound policy with explicit exceptions.")

    for section in ("services", "files"):
        if section in config and not isinstance(config[section], list):
            raise ValueError(f"{section} must be a list")
    for service in config.get("services", []):
        if not isinstance(service, dict) or not {"name", "port", "bind"}.issubset(service):
            raise ValueError("each service needs name, port and bind")
        if not isinstance(service["name"], str) or not service["name"]:
            raise ValueError("service name must be a nonempty string")
        if type(service["port"]) is not int or not 1 <= service["port"] <= 65535:
            raise ValueError("service port must be an integer from 1 to 65535")
        if not isinstance(service["bind"], str):
            raise ValueError("service bind must be an IPv4 or IPv6 address string")
        try:
            address = ip_address(service["bind"])
        except (ValueError, TypeError) as error:
            raise ValueError("service bind must be an IPv4 or IPv6 address") from error
        detail = f"{service['name']} on {address}:{service['port']}"
        if service["port"] in {21, 23}:
            flag("cleartext-service", "high", detail + " uses a commonly cleartext protocol port.",
                 "Verify the protocol, retire FTP/Telnet where present, and use encrypted alternatives such as SFTP/SSH.")
        if service["port"] in {22, 3389, 5432, 3306} and address.is_unspecified:
            flag("broad-listener", "medium", detail + " listens on all interfaces.",
                 "Restrict the bind address and firewall sources where appropriate. A wildcard bind alone does not prove Internet exposure.")
    for file in config.get("files", []):
        if not isinstance(file, dict) or not {"path", "mode", "sensitive"}.issubset(file):
            raise ValueError("each file needs path, mode and sensitive")
        if not isinstance(file["path"], str) or not file["path"] or type(file["sensitive"]) is not bool:
            raise ValueError("file path must be nonempty and sensitive must be bool")
        mode_text = file["mode"]
        if not isinstance(mode_text, str) or len(mode_text) not in {3, 4} or any(c not in "01234567" for c in mode_text):
            raise ValueError("file mode must be a 3-4 digit octal string")
        mode = int(mode_text, 8)
        if mode & 0o002:
            flag("world-writable", "high", f"{file['path']} has mode {mode_text} (others can write).",
                 "Remove write permission for others after checking the file's purpose; review owner and group too.")
        if file["sensitive"] and mode & 0o044:
            flag("sensitive-readable", "high", f"{file['path']} is marked sensitive but group/others can read it ({mode_text}).",
                 "Restrict access to the intended owner or a justified group; investigate possible disclosure.")
    return findings


def report(findings):
    lines = ["# Security baseline review", "", f"{len(findings)} findings in the supplied snapshot.",
             "Sample configuration only. No live host was scanned or modified.", ""]
    for finding in findings:
        lines += [f"## {finding['severity'].upper()} — {finding['rule']}", finding["evidence"],
                  f"Recommendation: {finding['recommendation']}", ""]
    if not findings:
        lines.append("No rules matched. This narrow check is not a security certification.")
    return "\n".join(lines).rstrip() + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("json_file", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        config = json.loads(args.json_file.read_text(encoding="utf-8"))
        text = report(check(config))
    except (OSError, ValueError) as error:
        parser.error(str(error))
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
