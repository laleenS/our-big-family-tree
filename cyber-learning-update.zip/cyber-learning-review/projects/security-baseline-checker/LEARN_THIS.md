# Learn this before presenting the baseline checker

This project reads **invented JSON snapshots**, not your Windows settings and not a
real Linux server. It never scans a host or opens the `/sample/` paths. The Python
sample was run in the cloud; you should run it and explain it yourself before using
it in an interview. Do not run Linux chmod/SSH commands on Windows for this exercise.

On Windows, open PowerShell in this project and use Python 3.11+:

```powershell
py src/check_baseline.py data/insecure.json --output sample-report.md
py src/check_baseline.py data/safer.json
py -m unittest discover -s tests -v
```

No packages or administrator rights are needed. `python` is an alternative if it
points to Python 3.11+; Linux uses `python3`. Compare the insecure JSON, eight-finding
report and safer control. `safer.json` matching these rules is not a security guarantee.

## Files and code

`src/check_baseline.py` loads JSON into dictionaries and lists. `check()` loops over
settings/services/files and collects finding dictionaries. The small `setting()`
helper checks a field's presence/type; `flag()` appends a finding. They are functions
inside `check()` so they use its current findings list, not a new framework.
`report()` formats Markdown; `main()` handles filenames. `tests/test_baseline.py`
checks known findings, missing data, invalid types, IPv6 and permission bits.

Two concepts to learn beyond basic dictionaries:

1. **Permission bit masks.** Octal strings describe Unix permission bits, not Windows
   ACLs. `int("0644", 8)` turns an octal string into a number. `mode & 0o002` asks
   whether the write-for-others bit is set. `mode & 0o044` asks whether group or others
   can read. `&` is a bitwise test, not Python's logical `and`. Work through the
   three-digit owner/group/other permissions by hand before relying on a result.
2. **IP address classification.** `ipaddress.ip_address()` parses IPv4/IPv6 addresses.
   `.is_unspecified` is true for `0.0.0.0` and `::`, meaning an all-interface bind
   in this snapshot. It does not perform a network probe or establish reachability.

## What the controls do and why they matter

| Control | Technical check | Explain the security reason |
| --- | --- | --- |
| Root SSH | permit_root_login=true | Named identities aid accountability; direct shared root login concentrates privilege |
| SSH passwords | password_authentication=true | Managed keys/MFA can reduce password-only exposure, but access changes need recovery planning |
| Password length | min_length below the lab target of 15 | Longer passphrases help resist guessing, but length alone cannot prevent reuse/phishing |
| Firewall | firewall_enabled=false | Limiting allowed inbound flows reduces exposure; an enabled flag does not prove good rules |
| Cleartext service | Port 21/23 in supplied service list | FTP/Telnet often expose sensitive traffic; a port number alone does not prove the protocol |
| Broad listener | Admin/database port bound to 0.0.0.0 or :: | More reachable interfaces can increase exposure; routes/firewalls still decide actual access |
| File write | Others-write bit set | Other local identities could alter a file; consider path purpose, owner, sticky bit and ACLs too |
| Sensitive read | Group/others-read bit on a sensitive-marked file | Confidential content should have a justified readership; restricted group sharing can be legitimate |
| Missing setting | Required section/field absent | Unknown evidence cannot honestly be labeled secure/compliant |
| Severity | Simple high/medium categories | Prioritize review while considering context; these are lab judgments, not CVSS scores |

Windows file permissions use ACLs rather than these Unix mode bits. That difference
is an interview learning point, not something this JSON checker implements.

## Ten interview questions — points to understand

1. **Is this a vulnerability scanner?** A small supplied-configuration checker; no
   network scan, CVE database, package discovery or live-host collection.
2. **What is the difference between 0644 and 0600?** Owner read/write stays the same;
   0644 also allows group and others to read.
3. **What does `mode & 0o002` test?** The write bit for others, not owner/group write.
4. **Can file mode alone establish access?** No; owner/group, ACLs, parent-directory
   permissions and filesystem context can change effective access.
5. **Does a wildcard listener prove Internet exposure?** No; explain interfaces,
   loopback, routing and host/network firewalls separately.
6. **Why not automatically remediate?** Wrong permissions or access changes can
   break applications or lock you out; review and test recovery first.
7. **What does a missing setting mean?** Unknown/incomplete evidence; the tool
   produces a finding instead of assuming a secure default.
8. **Why can a port-based check be wrong?** Services can use unusual ports or
   encrypted variants; verify protocol/configuration rather than naming it from a port.
9. **Does the safer JSON prove compliance?** No; it matches a narrow lab policy,
   not a full standard, effective configuration or independent audit.
10. **How would this differ on your Windows computer?** Windows ACLs, event sources
    and services need a different authorized collector and policy; this tool only reads JSON.

Practice yourself: rewrite the two permission tests, calculate outputs for 0600,
0640, 0644, 0666 and 0777, then edit the sample and predict the findings. Keep the
scope modest and never claim a real host or government system was scanned.
