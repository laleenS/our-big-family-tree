import copy
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from check_baseline import check

ROOT = Path(__file__).resolve().parents[1]


class BaselineTests(unittest.TestCase):
    def setUp(self):
        self.safer = json.loads((ROOT / "data/safer.json").read_text())

    def test_insecure_fixture_and_safer_control(self):
        insecure = json.loads((ROOT / "data/insecure.json").read_text())
        self.assertEqual({f["rule"] for f in check(insecure)}, {
            "root-ssh", "ssh-password", "short-password", "firewall-disabled",
            "cleartext-service", "broad-listener", "sensitive-readable", "world-writable"})
        self.assertEqual(len(check(insecure)), 8)
        self.assertEqual(check(self.safer), [])

    def test_missing_is_unknown_and_not_a_pass(self):
        self.assertEqual(len(check({})), 5)
        del self.safer["ssh"]["permit_root_login"]
        self.assertEqual([f["rule"] for f in check(self.safer)], ["missing-setting"])

    def test_boolean_strings_and_invalid_modes_rejected(self):
        bad = copy.deepcopy(self.safer)
        bad["firewall_enabled"] = "false"
        with self.assertRaisesRegex(ValueError, "bool"):
            check(bad)
        bad = copy.deepcopy(self.safer)
        bad["files"][0]["mode"] = "0688"
        with self.assertRaisesRegex(ValueError, "octal"):
            check(bad)

    def test_ipv6_wildcard_and_permission_bits(self):
        self.safer["services"][0]["bind"] = "::"
        self.safer["files"][0]["mode"] = "0602"
        self.assertEqual({f["rule"] for f in check(self.safer)}, {"broad-listener", "world-writable"})


if __name__ == "__main__":
    unittest.main()
