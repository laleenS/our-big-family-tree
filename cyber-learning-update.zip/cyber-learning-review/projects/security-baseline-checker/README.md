# Security baseline checker

A Python checker for a **supplied sample JSON snapshot**, not a live vulnerability
scan. I wrote checks for SSH settings, password length, firewall state, broad service
listeners, cleartext service ports, and file permission bits. It reports severity,
evidence, and a suggested next step without changing anything on the host.

Use Python 3.11+ in this folder. No packages, root privileges, or credentials needed:

```powershell
py src/check_baseline.py data/insecure.json --output sample-report.md
py src/check_baseline.py data/safer.json
py -m unittest discover -s tests -v
```

The first example produces eight findings. The second matches this small baseline
and produces none; it is not proof that a real server is secure. Reports go to the
terminal and optionally to a Markdown file. Analysis exits zero even with findings;
invalid JSON or invalid field types exit nonzero. On Linux use `python3` instead of `py`.
Start with [LEARN_THIS.md](LEARN_THIS.md) for the code, security concepts and ten
interview questions. This sample models Unix-style permissions, not Windows ACLs.

## What the rules mean

- **High:** direct root SSH, a disabled host firewall, FTP/Telnet port use, a
  world-writable file, or a sensitive file readable outside its owner.
- **Medium:** SSH passwords, a minimum password length below this lab's 15-character
  target, all-interface listeners for common administration/database ports, and
  missing required settings. Missing data means unknown, not compliant.

`data/safer.json` shows changes to compare with `data/insecure.json`. For example,
`0644` grants group/other read permission; `0600` keeps owner read/write only.
`0777` grants write permission to everyone. Paths under `/sample/` are fictional;
no file at those paths is opened. JSON modes must be octal strings, such as `"0600"`.

I practiced JSON validation, bit masks, IPv4/IPv6 bind addresses, and explaining
configuration risk without exaggerating it. A service bound to `0.0.0.0` or `::`
listens on all interfaces, but routing and firewalls decide actual reachability.

Limits: input is self-reported, not collected from Linux; port numbers do not prove
a protocol; no package/CVE checks, ACLs, ownership checks, firewall-rule parsing,
MFA validation, or effective sshd configuration resolution. This is not a CIS/NIST
compliance tool. The 15-character threshold is a lab choice for password-only use;
real policy must also consider MFA, compromised-password screening, and context.
Sensitive files can legitimately use a restricted group, so investigate before
changing permissions. Test remote access/recovery before changing SSH or firewall
settings. No automatic remediation is included.
