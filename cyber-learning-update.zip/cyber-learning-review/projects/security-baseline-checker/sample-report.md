# Security baseline review

8 findings in the supplied snapshot.
Sample configuration only. No live host was scanned or modified.

## HIGH — root-ssh
Direct root SSH login is enabled.
Recommendation: Use named accounts with reviewed sudo access; disable direct root login after testing recovery access.

## MEDIUM — ssh-password
SSH accepts password authentication.
Recommendation: Prefer managed SSH keys and MFA where available; verify working access before disabling passwords.

## MEDIUM — short-password
Minimum password length is 8; lab target is 15.
Recommendation: Use long passwords/passphrases, a breached-password blocklist, and MFA. Length alone is insufficient.

## HIGH — firewall-disabled
Snapshot reports host firewall disabled.
Recommendation: Review required flows, then enable a default-deny inbound policy with explicit exceptions.

## HIGH — cleartext-service
telnet-demo on 0.0.0.0:23 uses a commonly cleartext protocol port.
Recommendation: Verify the protocol, retire FTP/Telnet where present, and use encrypted alternatives such as SFTP/SSH.

## MEDIUM — broad-listener
database-demo on 0.0.0.0:5432 listens on all interfaces.
Recommendation: Restrict the bind address and firewall sources where appropriate. A wildcard bind alone does not prove Internet exposure.

## HIGH — sensitive-readable
/sample/app.env is marked sensitive but group/others can read it (0644).
Recommendation: Restrict access to the intended owner or a justified group; investigate possible disclosure.

## HIGH — world-writable
/sample/start.sh has mode 0777 (others can write).
Recommendation: Remove write permission for others after checking the file's purpose; review owner and group too.
