# SOC investigation lab

A small Python lab for practicing the path from log event to detection, triage,
evidence, analyst decision, and recommended response. All 18 events are invented.
The Python utility was run in the cloud workspace; **Splunk, Sysmon, and Windows
telemetry collection have not been run for this project**.

## Run the sample on Windows

Install Python 3.11+ from [python.org](https://www.python.org/downloads/windows/).
Open PowerShell in this folder (not an administrator window):

```powershell
py --version
py src/investigate.py data/events.csv --output output/findings.md
py -m unittest discover -s tests -v
```

If `py` is unavailable but `python --version` shows 3.11+, use `python` instead.
On Linux, the equivalent command starts with `python3`. No packages to install.
Successful analysis exits zero even with findings; invalid input exits nonzero.
The utility reads normalized CSV, **not** raw Windows EVTX or Splunk exports.

Start with [LEARN_THIS.md](LEARN_THIS.md). Then compare the nine generated leads in
[output/findings.md](output/findings.md) with the five exercises in
[investigations/scenarios.md](investigations/scenarios.md). Rule definitions are in
[detections/rules.md](detections/rules.md); use the [triage checklist](docs/triage.md).
Usernames are fictional, IPs are documentation ranges, and the encoded command is
only `Write-Output 'LAB'`, stored as text. The utility never executes log commands.

## Next hands-on step

Follow [docs/windows-splunk-lab.md](docs/windows-splunk-lab.md) on your own Windows
computer. The plan uses Windows Security logs, a narrowly scoped Sysmon config, and
Splunk Enterprise on the same PC. A second machine or enterprise domain is not
required. Licensing, supported Windows versions, and available resources must be
checked before installation. This extension is **planned, not completed**. Keep
live results separate and document what you personally ran.

Limits: fixed sample source list and UTC hours, batch-only analysis, no spraying
correlation across users/IPs, no MFA/device evidence, no real incident response, and
only exact encoded PowerShell switches (not every abbreviation or obfuscation).
A matching rule does not establish compromise. SPL searches supplied for the next
stage have not been executed against Splunk.
