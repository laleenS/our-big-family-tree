# Learn this before presenting the SOC lab

Start with the CSV version. You do not need to understand a live SIEM first. Be
honest: the sample analysis was executed by the coding assistant in the cloud;
you still need to run it, understand it, and later collect your own Windows evidence.

## Read and run in this order

1. Open `data/events.csv`. Follow E001–E006 by account, computer, source and time.
2. Run the README commands in Windows PowerShell. Compare `output/findings.md`.
3. Read `src/investigate.py`: `read_events`, `investigate`, then `report`.
4. Read `investigations/scenarios.md` and ask why two matching patterns can have
   different verdicts. Rebuild the five-failure rule yourself before adding features.
5. Start `docs/windows-splunk-lab.md` only after the sample version makes sense.

## How the Python works

`csv.DictReader` gives one dictionary per row. The reader checks required fields,
unique evidence IDs, IPs and timestamp formats. A bad row stops the run so it cannot
silently distort the result. `utf-8-sig` also accepts a Windows UTF-8 BOM.

Two useful new ideas:

- **Timezone-aware datetime:** `2026-10-01T09:00:00Z` means 09:00 UTC. Python converts
  a supplied offset to UTC, sorts by time, and subtracts two dates to get elapsed
  time. The five-minute test includes exactly five minutes. A timestamp without a
  timezone is rejected because guessing its timezone could change a verdict.
- **A grouped dictionary key:** `(computer, user, source_ip)` is a tuple: three
  values used together as one dictionary key. Each key holds a normal list of recent
  failed events. A loop copies only events still in the five-minute window. This
  prevents failures on two different computers or users being combined by accident.

`finding()` packages a few values into a dictionary; `report()` formats them as
Markdown. The CLI (`argparse`) only reads filenames/options. It is plumbing, not a
security detection. `if __name__ == '__main__'` lets tests import functions without
running the CLI. Standard-library tests use classes because unittest expects them;
the detector itself has no class hierarchy, async code or third-party packages.

Try changing one failure to occur six minutes earlier. Predict whether the success
still has five preceding failures, then run the tool. Do not paste unknown commands
from logs into PowerShell.

## Technical behavior and why the security idea matters

| Concept | What the project does | What to explain when asked why it matters |
| --- | --- | --- |
| Telemetry | Reads invented authentication and process rows | Analysts need records of activity before they can reason about it; collection gaps limit conclusions |
| Detection | Checks five explicit patterns | A rule selects activity for review; it does not decide whether a person is an attacker |
| Brute-force lead | Counts failures for one target/account/source | Repeated failures can indicate guessing, but typing mistakes and saved credentials also produce them |
| Success after failures | Raises a higher-priority lead | Success changes the possible impact; verify ownership and subsequent activity rather than assuming compromise |
| PowerShell | Flags exact encoded switches and preserves evidence IDs | PowerShell is a legitimate Windows tool; command intent and authorization matter more than the executable name |
| Encoding | Sample Base64 is harmless UTF-16LE text | Base64 is representation, not encryption, and does not prove maliciousness; inspect decoded text without executing it |
| Baselines | Uses two known IPs and UTC hour defaults | “Unusual” depends on normal work, VPNs and timezone; a tiny sample baseline creates false positives |
| Triage | Checklist identifies fields and missing context | A Tier-1 analyst prioritizes, records evidence and escalates within a response procedure |
| Evidence | Findings point back to unique CSV IDs | Another reviewer should be able to reproduce the timeline and see why the verdict follows |
| ATT&CK | Uses T1110/T1078 as hypotheses, T1059.001 for PowerShell behavior | Technique labels organize behavior; they are not proof or attacker attribution |
| False positives | Worked examples include invented helpdesk/change context | Closing a benign alert needs evidence; broad allowlists can hide real misuse |
| SIEM | Splunk is planned for collecting/searching Windows events | A SIEM centralizes telemetry and searches; this Python CSV script is not itself a SIEM |

## Ten interview questions — points to understand, not a script to memorize

1. **Walk through the lab from event to response.** Know CSV → rule → finding →
   raw evidence/timeline → context → verdict → recommended next step.
2. **Why group by three fields?** Explain target/account/source separation and what
   distributed guessing or password spraying would miss.
3. **What does a successful login after failures prove?** Only an observed pattern;
   owner, MFA and session evidence are still needed.
4. **Why does the five-minute boundary matter?** Exactly five minutes is included;
   six minutes is outside; tests guard against accidental count changes.
5. **Is encoded PowerShell malicious?** No; distinguish command content, parent,
   user, approval and session correlation.
6. **How did you identify a false positive?** In this exercise, explicit synthetic
   owner/ticket context; in a real lab, collect the equivalent evidence yourself.
7. **Why not map every odd login to ATT&CK?** Odd time/IP alone does not establish
   technique use. Explain behavior before naming a technique.
8. **What is missing from the data?** LogonId, MFA, device details, full endpoint
   context and real authorization evidence; correlation by time alone is limited.
9. **What would you do as a Tier-1 analyst?** Preserve evidence and escalate using
   procedure; containment actions need appropriate authorization and corroboration.
10. **What have you personally run?** Separate the prepared/tested CSV utility from
    your own future Python run and not-yet-completed Splunk/Sysmon collection.

Before interviewing, rewrite the rolling-window loop, add one test, and write a new
investigation note in your own words. Once you run the live lab, record its actual
versions, searches, errors, screenshots and conclusions; do not backfill invented results.
