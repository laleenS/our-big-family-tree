import copy
import sys
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from investigate import investigate, read_events

ROOT = Path(__file__).resolve().parents[1]


class InvestigationTests(unittest.TestCase):
    def setUp(self):
        self.events = read_events(ROOT / "data/events.csv")

    def test_sample_evidence_and_control(self):
        findings = investigate(self.events)
        self.assertEqual(len(self.events), 18)
        self.assertEqual(len(findings), 9)
        success = findings[1]
        self.assertEqual(success["rule"], "success-after-failures")
        self.assertEqual(success["evidence_ids"], ["E001", "E002", "E003", "E004", "E005", "E006"])
        for item in findings:
            self.assertNotIn("lab.student04", item["user"])
        encoded = [item["evidence_ids"] for item in findings if item["rule"] == "encoded-powershell"]
        self.assertEqual(encoded, [["E007"], ["E015"]])

    def test_inclusive_window_expiry_and_success_reset(self):
        events = copy.deepcopy(self.events[:6])
        start = events[0]["time"]
        for index, event in enumerate(events):
            event["time"] = start + timedelta(seconds=[0, 60, 120, 180, 300, 300][index])
        findings = investigate(events)
        self.assertIn("success-after-failures", [item["rule"] for item in findings])
        repeated_success = copy.deepcopy(events[-1])
        repeated_success["event_id"] = "REPEAT"
        self.assertEqual(sum(item["rule"] == "success-after-failures" for item in investigate(events + [repeated_success])), 1)
        events[-1]["time"] += timedelta(seconds=1)
        self.assertNotIn("success-after-failures", [item["rule"] for item in investigate(events)])

    def test_accounts_sources_and_hosts_are_separate(self):
        for field in ["computer", "user", "source_ip"]:
            events = copy.deepcopy(self.events[:6])
            events[0][field] = "192.0.2.99" if field == "source_ip" else "other"
            self.assertNotIn("success-after-failures", [item["rule"] for item in investigate(events)])

    def test_plain_powershell_and_unrelated_executable_do_not_match(self):
        process = copy.deepcopy(self.events[6])
        process["command_line"] = "powershell.exe -NoProfile -Command Write-Output"
        self.assertEqual(investigate([process]), [])
        process["command_line"] = "something.exe -enc text"
        process["image"] = "something.exe"
        self.assertEqual(investigate([process]), [])

    def test_reader_handles_bom_timezones_and_bad_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "events.csv"
            text = (ROOT / "data/events.csv").read_text()
            path.write_text(text.replace("2026-10-01T09:00:00Z", "2026-10-01T11:00:00+02:00"), encoding="utf-8-sig")
            self.assertEqual(read_events(path)[0]["time"], self.events[0]["time"])
            path.write_text(text.replace("2026-10-01T09:00:00Z", "2026-10-01T09:00:00"))
            with self.assertRaisesRegex(ValueError, "timezone"):
                read_events(path)
            path.write_text(text.replace("E002", "E001"))
            with self.assertRaisesRegex(ValueError, "unique"):
                read_events(path)


if __name__ == "__main__":
    unittest.main()
