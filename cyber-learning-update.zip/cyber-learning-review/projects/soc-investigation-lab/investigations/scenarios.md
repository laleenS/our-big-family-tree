# Synthetic investigation exercises

Every event, account, authorization note and verdict below is invented for practice.
These are worked examples, not evidence of personal live-lab experience. Each verdict
uses only the listed evidence/context. The tool raises leads; it does not set verdicts.

## 1. Repeated failures / possible brute force

- **Detection:** E001–E005, five failures for lab.student01 at LAB-PC from
  198.51.100.23 between 09:00 and 09:04 UTC on October 1, 2026.
- **Evidence reviewed:** those five CSV rows, same account/source/host, increasing
  timestamps. No MFA, lockout, owner confirmation or network reputation is supplied.
- **Why suspicious / context:** repeated failures in a short window could be guessing;
  an unfamiliar source increases the need to verify, but could be a VPN exit.
- **ATT&CK hypothesis:** T1110 (Brute Force). The events do not prove that technique.
- **Verdict:** **suspicious / needs escalation**. There is insufficient evidence for
  a true-positive compromise decision.
- **Next steps:** check failure reason, logon type, normal source history, account
  owner and MFA evidence; follow the analyst escalation procedure if unrecognized.
- **False positives:** typos, an old saved password, shared NAT, a changed VPN source.

## 2. Successful authentication after failures

- **Detection:** E006 succeeds at 09:04:30 after E001–E005. It matches two rules:
  success-after-failures and unfamiliar-source.
- **Evidence reviewed:** E001–E006, then E007 as follow-on process context on the same
  computer/user. Time proximity is a lead; it does not prove the same logon session.
- **Why suspicious / context:** someone may have guessed a password, but the owner
  could simply have corrected a mistake. No LogonId/session linkage is supplied.
- **ATT&CK hypothesis:** T1078 (Valid Accounts) only if misuse is corroborated.
- **Verdict:** **suspicious / needs escalation**; success alone is not confirmation.
- **Next steps:** correlate LogonId, logon type and process/user session, verify with
  owner, review MFA, and recommend session revocation/reset only under the response
  process if evidence supports unauthorized use. Do not automatically block the IP.
- **False positives:** a person finally remembering their password or a support test.

## 3. Encoded PowerShell after the login

- **Detection:** E007 runs powershell.exe with -EncodedCommand at 09:05 from cmd.exe.
- **Evidence reviewed:** image, parent image, user, host, command and timestamp. The
  supplied UTF-16LE/Base64 text decodes to `Write-Output 'LAB'`: harmless output only.
  The sample intentionally contains no payload or network download.
- **Why suspicious / context:** encoded content requires review. Parent cmd.exe and
  timing alone cannot distinguish administration from misuse. There is no approval
  record for this event and no evidence connecting it to E006's session.
- **ATT&CK:** T1059.001 describes PowerShell use; not a claim of malicious execution.
- **Verdict:** **suspicious / needs escalation** for authorization verification, **not**
  a confirmed malicious command. The decoded content itself is benign.
- **Next steps:** decode as text without executing, ask for the task/approval, inspect
  related process events, and record what is missing. Do not run unknown commands.
- **False positives:** encoded commands can avoid quoting problems in management tools.

## 4. Unusual login time and source

- **Detection:** E008, lab.student02, 02:15 UTC on October 2 from 203.0.113.8; two low
  severity leads (off-hours and unfamiliar source).
- **Evidence reviewed:** one success event; no owner schedule, MFA or device context.
- **Why suspicious / context:** the source and time differ from the tiny lab baseline.
  UTC is not the user's local work time; travel or scheduled work could explain it.
- **ATT&CK:** no mapping justified by time/source novelty alone.
- **Verdict:** **suspicious / needs escalation**, pending routine contextual checks.
- **Next steps:** ask about work hours/travel, compare VPN egress and device/MFA history.
  Close as expected activity only if the supporting evidence actually agrees.
- **False positives:** remote work, different timezones, on-call work and VPN changes.

## 5. Two alerts explained by synthetic business context

- **Detection A:** E009–E014 repeat the failure/success pattern for lab.student03 from
  known source 192.0.2.10. **Detection B:** E015 is encoded PowerShell by lab.admin.
- **Evidence reviewed:** E009–E015 and the following **invented exercise context**:
  HELP-101 records an owner-confirmed password-typing issue at 10:00–10:05; CHANGE-201
  records lab.admin's approved 11:00 output-only PowerShell test on LAB-PC.
  These ticket notes are scenario assumptions, not records retrieved from a system.
- **Why suspicious / context:** both patterns match the rules exactly, but the
  supplied owner/approval context accounts for them. E015 decodes to the same harmless
  text as E007; authorization context, not the switch alone, changes the verdict.
- **ATT&CK:** T1110/T1078 are not established; T1059.001 can describe PowerShell use
  without malicious intent.
- **Verdict:** **false positive for malicious-activity escalation**, given this
  synthetic context. The rules correctly matched observable behavior.
- **Next steps:** document why the alerts are closed; if tuning is justified, scope
  it to the task/account/time and review it. Do not broadly allow all encoded commands.
- **False-positive lesson:** a known IP does not prove safety; in a real case verify
  the ticket, owner and session rather than inventing an explanation.

Control: E016–E018 contain two separated failures and daytime success from a known
source, so no rules match. This tests the threshold, not overall account safety.
No scenario has enough evidence for a confirmed malicious true-positive verdict;
that is a deliberate limitation, not a missing claim to fill in.
