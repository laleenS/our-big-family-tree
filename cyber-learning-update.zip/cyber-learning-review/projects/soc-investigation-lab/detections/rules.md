# Sample detection rules

Synthetic normalized CSV only. `event_id` is a row identifier such as E001, not a
Windows Event ID. The Python tool sorts timestamps, converts them to UTC, and
keeps equal timestamps in file order. Every row must have a unique evidence ID.

| Rule | Technical check | Why investigate | Possible ATT&CK mapping |
| --- | --- | --- | --- |
| repeated-failures | Five failures within an inclusive five-minute window for the same computer/user/source | Could be guessing or repeated password mistakes | T1110, if password guessing is supported by context |
| success-after-failures | Success with at least five prior failures in that window | An account might have been accessed after guessing | T1078 only if unauthorized valid-account use is corroborated |
| encoded-powershell | Process image is powershell.exe or pwsh.exe and arguments contain the exact token -EncodedCommand or -enc | Encoding can conceal intent; also common in legitimate administration | T1059.001 describes PowerShell execution; it does not establish maliciousness |
| off-hours-success | Success from 00:00 through 05:59 UTC | May differ from the account's normal schedule | None from time alone |
| unfamiliar-source | Success outside the two lab source addresses | Could be travel, VPN egress or misuse | None from IP novelty alone |

Failure alerts fire when the window count reaches five, not for every later failure.
A success resets that computer/user/source's stored failures. Expiry can allow a new
threshold crossing. Events from other computers must not accumulate together.

The source list and time threshold are lab defaults in `src/investigate.py`, not a
real organization's baseline. Multiple leads can describe one activity: E006 matches
two rules, which does not mean two compromises. Empty input has no matches, not a
security guarantee. Missing/invalid fields stop analysis rather than being discarded.

References: [T1110](https://attack.mitre.org/techniques/T1110/),
[T1078](https://attack.mitre.org/techniques/T1078/),
[T1059.001](https://attack.mitre.org/techniques/T1059/001/).
