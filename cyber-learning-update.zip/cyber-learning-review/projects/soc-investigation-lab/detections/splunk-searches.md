# Planned Splunk searches — not executed

These are starter SPL searches for the **future live lab**. They were not tested in
Splunk here. Use local XML-rendered inputs, the `windows_lab` index, and a time range
covering your actual events. Inspect raw events/field extraction before trusting a
count. The regexes assume the standard XML element/attribute names below; different
rendering or add-ons can change fields. Do not upload the normalized CSV and pretend
it is a Windows event channel.

## Check event IDs and hosts

```spl
index=windows_lab
| rex field=_raw "<EventID[^>]*>(?<lab_event_id>[0-9]+)</EventID>"
| rex field=_raw "<Computer>(?<lab_computer>[^<]+)</Computer>"
| stats count by lab_event_id lab_computer
```

## Find authentication events

```spl
index=windows_lab source="WinEventLog:Security"
| rex field=_raw "<EventID[^>]*>(?<lab_event_id>[0-9]+)</EventID>"
| where lab_event_id="4624" OR lab_event_id="4625"
| rex field=_raw "<Data Name=['\"]TargetUserName['\"]>(?<lab_user>[^<]*)</Data>"
| rex field=_raw "<Data Name=['\"]IpAddress['\"]>(?<lab_source_ip>[^<]*)</Data>"
| rex field=_raw "<Data Name=['\"]LogonType['\"]>(?<lab_logon_type>[^<]*)</Data>"
| table _time host lab_event_id lab_user lab_source_ip lab_logon_type
```

Check your actual `source` first: XML inputs may use `XmlWinEventLog:Security`
or another value. Replace the `source` constraint with the observed Security source;
do not remove the channel distinction and combine unrelated Event IDs.

## Basic repeated-failure search

Use the actual Security source value here too. This uses **fixed buckets**, not the
Python rolling window. A sequence spanning 09:04–09:06 can be split and missed.

```spl
index=windows_lab source="WinEventLog:Security"
| rex field=_raw "<EventID[^>]*>(?<lab_event_id>[0-9]+)</EventID>"
| where lab_event_id="4625"
| rex field=_raw "<Data Name=['\"]TargetUserName['\"]>(?<lab_user>[^<]+)</Data>"
| rex field=_raw "<Data Name=['\"]IpAddress['\"]>(?<lab_source_ip>[^<]+)</Data>"
| bin _time span=5m
| stats count AS failures by _time host lab_user lab_source_ip
| where failures >= 5
```

`stats ... by` drops rows missing a grouping field. Missing/`-`/loopback source data
needs its own review; do not assume this rule covers all local logons. For a success
after failures, first inspect the same account/host/source timeline manually around
a 4624 and check LogonType/session identifiers; no tested automated SPL correlation
for that behavior is claimed here.

## Inspect Sysmon PowerShell processes

Use the actual Sysmon source value from your input verification.

```spl
index=windows_lab source="WinEventLog:Microsoft-Windows-Sysmon/Operational"
| rex field=_raw "<EventID[^>]*>(?<lab_event_id>[0-9]+)</EventID>"
| where lab_event_id="1"
| rex field=_raw "<Data Name=['\"]Image['\"]>(?<lab_image>[^<]+)</Data>"
| rex field=_raw "<Data Name=['\"]CommandLine['\"]>(?<lab_command>[^<]*)</Data>"
| rex field=_raw "<Data Name=['\"]ParentImage['\"]>(?<lab_parent>[^<]*)</Data>"
| rex field=_raw "<Data Name=['\"]User['\"]>(?<lab_user>[^<]*)</Data>"
| where match(lower(lab_image), "(powershell|pwsh)[.]exe$")
| table _time host lab_user lab_image lab_parent lab_command
```

To narrow this to encoded switches, insert this line **before** `table`:

```spl
| where match(lower(lab_command), "(^|[[:space:]])-(encodedcommand|enc)([[:space:]]|$)")
```

Check the live SPL documentation and inspect extracted values if the input format
differs. The PowerShell image search uses an executable-name suffix as a first pass;
verify the complete image path in each result. These are planned examples to validate,
not proof of a working saved search or alert.
XML entities may appear in command text; inspect the original event too. PowerShell
4104 Script Block Logging is a different channel/event and is not enabled by the
supplied Sysmon config or used by these searches.
