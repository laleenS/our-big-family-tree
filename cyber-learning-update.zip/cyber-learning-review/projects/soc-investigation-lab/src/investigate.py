"""Find investigation leads in the lab's normalized synthetic CSV, not raw EVTX."""
import argparse
import csv
from datetime import datetime, timedelta, timezone
from ipaddress import ip_address
from pathlib import Path

WINDOW = timedelta(minutes=5)
THRESHOLD = 5
KNOWN_SOURCES = ["192.0.2.10", "192.0.2.20"]


def event_time(event):
    return event["time"]


def read_events(path):
    events = []
    seen_ids = []
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        required = ["event_id", "timestamp", "event_type", "computer", "user",
                    "source_ip", "result", "image", "command_line", "parent_image"]
        for column in required:
            if column not in (reader.fieldnames or []):
                raise ValueError(f"Missing CSV column: {column}")
        for line, row in enumerate(reader, 2):
            try:
                for column in required:
                    if row[column] is None:
                        raise ValueError(f"Missing value for {column}")
                if not row["event_id"] or row["event_id"] in seen_ids:
                    raise ValueError("event_id must be present and unique")
                if not row["computer"] or not row["user"]:
                    raise ValueError("computer and user are required")
                time = datetime.fromisoformat(row["timestamp"].replace("Z", "+00:00"))
                if time.tzinfo is None:
                    raise ValueError("timestamp needs a timezone")
                row["time"] = time.astimezone(timezone.utc)
                if row["event_type"] == "authentication":
                    ip_address(row["source_ip"])
                    if row["result"] not in ["failure", "success"]:
                        raise ValueError("authentication result must be failure or success")
                elif row["event_type"] == "process":
                    if not row["image"] or not row["command_line"]:
                        raise ValueError("process needs image and command_line")
                else:
                    raise ValueError("event_type must be authentication or process")
            except (ValueError, TypeError) as error:
                raise ValueError(f"Line {line}: {error}") from error
            seen_ids.append(row["event_id"])
            events.append(row)
    return sorted(events, key=event_time)


def finding(rule, severity, event, evidence_ids, detail):
    return {"rule": rule, "severity": severity, "time": event["time"].isoformat(),
            "computer": event["computer"], "user": event["user"],
            "evidence_ids": evidence_ids, "detail": detail}


def investigate(events):
    failures = {}
    findings = []
    for event in events:
        if event["event_type"] == "process":
            image = event["image"].replace("\\", "/").split("/")[-1].lower()
            arguments = event["command_line"].lower().split()
            if image in ["powershell.exe", "pwsh.exe"]:
                if "-encodedcommand" in arguments or "-enc" in arguments:
                    findings.append(finding("encoded-powershell", "medium", event,
                                            [event["event_id"]],
                                            "PowerShell used an encoded-command switch. Inspect the command and authorization; encoding alone is not malicious."))
            continue

        # Keep failures separate for each target computer, account and source.
        key = (event["computer"], event["user"], event["source_ip"])
        if key not in failures:
            failures[key] = []
        recent = []
        for earlier in failures[key]:
            if event["time"] - earlier["time"] <= WINDOW:
                recent.append(earlier)
        failures[key] = recent
        evidence = []
        for earlier in recent:
            evidence.append(earlier["event_id"])
        evidence.append(event["event_id"])

        if event["result"] == "failure":
            recent.append(event)
            if len(recent) == THRESHOLD:
                findings.append(finding("repeated-failures", "medium", event, evidence,
                                        f"{THRESHOLD} failures in 5 minutes from {event['source_ip']}. Possible password guessing; review context."))
        else:
            if len(recent) >= THRESHOLD:
                findings.append(finding("success-after-failures", "high", event, evidence,
                                        f"Success after {len(recent)} recent failures from {event['source_ip']}. Validate the user and session; not proof of compromise."))
            if event["time"].hour < 6:
                findings.append(finding("off-hours-success", "low", event, [event["event_id"]],
                                        "Success before 06:00 UTC. Check actual work hours and local timezone."))
            if event["source_ip"] not in KNOWN_SOURCES:
                findings.append(finding("unfamiliar-source", "low", event, [event["event_id"]],
                                        f"Source {event['source_ip']} is outside the two known lab addresses. Check VPN/travel context."))
            failures[key] = []
    return findings


def report(events, findings):
    lines = ["# Synthetic SOC findings", "", f"Reviewed {len(events)} events; {len(findings)} findings.",
             "Generated by the Python utility from invented CSV data. No live Windows/Sysmon/Splunk evidence.",
             "These are investigation leads, not automated analyst verdicts. See investigations/scenarios.md.", ""]
    for item in findings:
        lines.append(f"## {item['severity'].upper()} — {item['rule']}")
        lines.append(f"UTC: {item['time']} | Computer: {item['computer']} | User: {item['user']}")
        lines.append("Evidence IDs: " + ", ".join(item["evidence_ids"]))
        lines.append(item["detail"])
        lines.append("")
    if not findings:
        lines.append("No rules matched; this does not establish that all activity is safe.")
    return "\n".join(lines).rstrip() + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        events = read_events(args.csv)
        text = report(events, investigate(events))
        if args.output:
            args.output.write_text(text, encoding="utf-8")
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(text, end="")


if __name__ == "__main__":
    main()
