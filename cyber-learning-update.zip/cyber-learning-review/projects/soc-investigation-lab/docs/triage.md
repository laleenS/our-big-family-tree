# First-pass triage checklist

For the synthetic exercises now, then your own live evidence later:

1. Record rule name, UTC time range, computer, account and evidence IDs. Confirm the
   source and timezone; make sure the events really describe the same target.
2. Read raw records before relying on the alert summary. Check whether fields are
   missing and whether a count includes duplicates.
3. Build a short timeline. For authentication, check failures, success, logon type
   and source. For process activity, check image, command line, parent and user.
4. Ask what context would explain the activity: owner, MFA, device, VPN, shift work,
   a change ticket. Mark unavailable evidence as unavailable, not as confirmation.
5. Decide: false positive, suspicious/needs escalation, or true positive supported
   by evidence. State what could change your decision. A rule match alone is not enough.
6. Recommend the next owner/action. A Tier-1 analyst normally escalates under a
   procedure; do not invent authority to disable accounts or isolate endpoints.
7. Save a redacted query, timeline and evidence. Record data source, collection date,
   query range, assumptions, verdict and follow-up. Distinguish observations from guesses.
