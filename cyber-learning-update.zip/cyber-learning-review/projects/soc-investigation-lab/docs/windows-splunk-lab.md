# Next hands-on step: one Windows PC, Sysmon and Splunk

**Status: instructions prepared, not executed.** The coding environment is Linux.
No Windows, Sysmon installation, Splunk search, alert or screenshot is claimed here.
Use a personal/test computer you are allowed to administer, not an employer/school
managed endpoint. This guide collects your computer's real usernames, paths and
commands: keep raw logs private and redact exports before publishing.

## 1. What the components do

- **Windows Security log:** Windows' built-in auditing, including successful logons
  (4624) and failed logons (4625) when the relevant auditing is enabled.
- **Sysmon:** Microsoft's Sysinternals System Monitor, a service/driver that records
  selected endpoint activity. Its Event ID 1 records process creation with image,
  command line, parent and user. Sysmon is telemetry, not an antivirus or SIEM. It
  does **not** replace Security log authentication auditing.
- **Splunk Enterprise:** collects/indexes events and lets you search them with SPL.
  A rule can become an alert, but an analyst still investigates it.
- **MITRE ATT&CK:** a vocabulary for observed behavior. It does not decide a verdict.

Use the same PC for Splunk Enterprise's local Windows event-log input and Sysmon.
A Universal Forwarder, Splunk Cloud, Active Directory, VMs and a second computer are
not required for this path. If you later choose Splunk Cloud, the ingestion path
changes and you will usually need a forwarder; that is outside these steps.

## 2. Check resources and downloads first

Record your Windows edition/build, free disk, RAM and administrator permission.
Check the **current** Splunk supported-Windows and hardware requirements; choose a
currently supported 64-bit installer. Start with short captures and a small daily
volume. If the PC cannot spare resources, finish the Python sample first and defer
Splunk rather than forcing it onto the computer. There is no cloud bill in this
local plan, but Splunk license/trial/ingest terms vary. Verify the current offer;
alerting may be unavailable after a trial expires. Do not assume indefinite free use.

Official references (UI labels and download versions may change):

- [Sysmon documentation/download](https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon)
- [Windows event 4624](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4624)
- [Windows event 4625](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4625)
- [Splunk Enterprise downloads](https://www.splunk.com/en_us/download/splunk-enterprise.html)
- [Splunk documentation](https://docs.splunk.com/Documentation/Splunk/latest)
- [Monitoring Windows event logs](https://docs.splunk.com/Documentation/Splunk/latest/Data/MonitorWindowseventlogdata)
- [inputs.conf reference](https://docs.splunk.com/Documentation/Splunk/latest/Admin/Inputsconf)

These official pages were not fetched from this restricted cloud environment; check
current requirements and flags there before installing. No third-party Sysmon rule
pack or copied GitHub implementation is required for this beginner lab.

## 3. Install and verify Sysmon

Download Microsoft's Sysmon ZIP and extract it to a folder you control, for example
`C:\Labs\Sysmon`. Keep the XML file in this project under review first. For an x64
PC, open **administrator PowerShell** in the extracted tool directory:

```powershell
Get-AuthenticodeSignature .\Sysmon64.exe | Format-List Status,SignerCertificate
.\Sysmon64.exe -s
```

Require a valid Microsoft signature; do not proceed on an invalid or untrusted
signature. `-s` prints the supported configuration schema. The supplied
`docs\sysmon-lab.xml` requests schema 4.90. If your official binary rejects it,
consult its schema/documentation rather than guessing fields or disabling checks.
Do not replace an existing Sysmon installation/configuration: inspect it first and
keep it intact. On a computer with no existing Sysmon setup, review the Microsoft
license, then install using the actual path to this project:

```powershell
.\Sysmon64.exe -accepteula -i C:\Labs\soc-investigation-lab\docs\sysmon-lab.xml
Get-Service Sysmon*
Get-WinEvent -ListLog 'Microsoft-Windows-Sysmon/Operational'
```

The XML includes PowerShell/pwsh/cmd process creation to keep the *process* exercise
small. It is a teaching filter, **not a complete security monitoring configuration**;
other Sysmon event categories may use defaults. Inspect the active config with
`.\Sysmon64.exe -c` and actual event volume. Do not assume the XML captures every
process or every threat, or that it is an all-category privacy filter.

Close administrator PowerShell. In **ordinary PowerShell**, make one benign event:

```powershell
powershell.exe -NoProfile -Command "Write-Output 'SOC lab test'"
```

In Event Viewer, look under Applications and Services Logs → Microsoft → Windows →
Sysmon → Operational. Inspect a recent Event ID 1: Image, User, ParentImage,
CommandLine and UtcTime. If absent, check service/config/time/filter before moving on.

## 4. Generate a few local authentication events safely

In Event Viewer, inspect Windows Logs → Security. Do not change audit policy unless
you own the PC and understand the existing setting. On Windows editions with Local
Security Policy, inspect Advanced Audit Policy → Logon/Logoff → Audit Logon for
success and failure. Record the prior setting before any authorized change; on a
managed computer stop and use a personal lab PC. Event availability varies by build,
policy, account type and authentication method.

Optional: create a disposable **standard** local test user using Windows Settings
(Accounts → Other users; labels vary). Choose a unique lab-only password privately;
do not put it in a script, log screenshot or repository. Use its real name below:

```powershell
runas /user:$env:COMPUTERNAME\SocLabUser "cmd.exe /c whoami"
```

At the interactive prompt, make **at most one** deliberate wrong entry, then run it
again with the right password. Close the resulting window. Check Security for
4625/4624, target user, time and LogonType. Do not brute-force accounts, alter
lockout policy or reuse a work account. Two events will **not** meet the five-failure
sample rule; the provided synthetic CSV already tests that threshold safely.
If local account creation is unavailable, use existing authorized normal logon
activity and record that limitation. Windows Hello unlocks may differ from password
logons. A local event may show source address `-` or loopback; do not invent a remote IP.

## 5. Get both channels into local Splunk

Install a supported Splunk Enterprise Windows build using its official installer.
Keep its web interface local, choose a private strong administrator password, and
avoid opening firewall ports for this one-PC lab. Confirm the service is running
and sign in using the local web address shown by the installer (commonly port 8000).
Do not confuse this with a Splunk Cloud trial.

Create an index named `windows_lab` with a small retention/disk budget. In Add Data
or Settings → Data Inputs, choose **local Windows Event Logs**, select Security
and Microsoft-Windows-Sysmon/Operational, and route both to `windows_lab`. Select XML
rendering if the version exposes it. Verify the actual selected channel names.
The Splunk service account must have appropriate permission to read them, especially
Security. A readable Sysmon channel does not prove Security access; inspect Splunk's
input errors. Follow the official service-account guidance rather than weakening
log ACLs or granting broad privileges as a shortcut.

If the UI cannot select the Sysmon channel, use the documented Windows input stanza
instead. Create a small local app directory under your actual Splunk installation,
for example `etc\apps\windows_lab\local\inputs.conf`, with the following content.
Do **not** create duplicate inputs if the UI already configured them, and do not
overwrite an existing configuration file. The `windows_lab` index must exist first.

```ini
[WinEventLog://Security]
disabled = 0
index = windows_lab
renderXml = true
start_from = oldest
current_only = 0

[WinEventLog://Microsoft-Windows-Sysmon/Operational]
disabled = 0
index = windows_lab
renderXml = true
start_from = oldest
current_only = 0
```

Restart Splunk through its supported service workflow after reviewing the file.
`oldest` can ingest older local logs: keep the capture short, monitor ingest limits,
and do not collect sensitive logs just to fill the index. Do not delete your Windows
logs to reset a lab. To pause collection, disable only the inputs you created.

Start with time picker **All time** and search `index=windows_lab | stats count by
source sourcetype`. Then narrow to your own test time. Verify one recent Security
and one Sysmon event against Event Viewer. Check host, timestamp/timezone, channel,
Event ID and raw XML. No results means investigate inputs, permissions, index,
time range or licensing; it does not mean “no threats.”

## 6. Authentication searches and one basic detection

See [../detections/splunk-searches.md](../detections/splunk-searches.md). The examples
use explicit XML `rex` extraction, so they do not assume a particular add-on has
created fields. They require XML inputs; inspect `_raw` first and adapt if the
format differs. Begin with 4624/4625 and your test username. Compare the returned
fields with Event Viewer, including LogonType and source address.

Run the five-failure example on the supplied CSV only with Python for now. The SPL
example is a **fixed five-minute bucket**, unlike Python's rolling window; failures
across a bucket boundary can be missed. Read that limitation before treating the
search as equivalent. Never generate repeated wrong passwords just to trigger it.

If your Splunk license supports scheduled alerts, save the reviewed five-failure
search with a matching time range and schedule. Record both. Overlapping schedules
can duplicate alerts and fixed buckets can miss activity; add scoped suppression
only after observing the behavior. Do not configure email/webhooks or claim a fired
alert without testing one. If alerting is unavailable, save a search and document a
manual simulated triage; do not present that as an automated alert.

## 7. Suspicious PowerShell search without a dangerous payload

Use the Sysmon Event ID 1 search first. If the approved ordinary output test appears,
you can make a harmless encoded variant in an ordinary PowerShell window:

```powershell
$text = "Write-Output 'SOC lab benign encoded test'"
$bytes = [System.Text.Encoding]::Unicode.GetBytes($text)
$encoded = [Convert]::ToBase64String($bytes)
powershell.exe -NoProfile -EncodedCommand $encoded
```

This prints text; it does not download or change anything. Record that **you**
authorized this benign command. Use the encoded-switch SPL search and compare image,
parent, command, user and timestamp with Event Viewer. You should be able to explain
why this is a false positive for malicious-activity escalation even if a rule matches.
Decode only your own sample as text; never execute an unknown decoded command.

## 8. Investigate and capture evidence

Use `triage.md`. Build a timeline with UTC/local time, account, host, Event IDs,
LogonType, source, Image/ParentImage and your exact SPL/time range. Sysmon Event ID 1
and Security Event ID 1 mean different things; channel/provider matters. Use
LogonId/LogonGuid and ProcessGuid if available for linkage, not just nearby timestamps.
Document authorization and classify the benign PowerShell test using evidence.
Unexpected activity should be described as unresolved, not embellished into a breach.

Create `evidence/live/` **only after** you collect real results. Suggested items:

- A dated note with Windows/Sysmon/Splunk versions, license mode, actual steps/errors.
- Redacted Event Viewer Event ID 1 and authentication event screenshots.
- Splunk input/index proof and a results screenshot showing SPL and time range.
- A detection match and your timeline, context, verdict and recommended next action.
- Exact queries and a small redacted export if safe and useful.

Do not photograph passwords, tokens, personal commands, work data, home addresses,
real public IPs or private account names. Redact a copy and label the redactions;
keep originals private. Screenshots must show what actually happened. This project
currently has **no live evidence screenshots**, and the supplied CSV is synthetic.

## 9. Cleanup and limitations

Pause only your Splunk lab inputs when done to limit collection. Remove the disposable
account if you created it. Restore any audit settings you intentionally changed.
If you installed Sysmon solely for this lab and choose to remove it, use the official
binary's documented `-u` command from administrator PowerShell; do not remove another
administrator's existing installation. Keep private logs out of Git.

This single-PC lab cannot reproduce domain-controller telemetry, enterprise MFA,
multiple endpoint correlation or real incident handling. One verified benign event,
correct search and honest investigation are better evidence than invented scale.
